Group Y "The Zealots" - ITC327W Assessment 2 (Phase 2: System Architecture and Design)
Project: Spanner - workshop booking, stock and invoicing system for Riese Auto Clinic.

CONTENTS (section 9 of the brief)
  Group Y - SRS (Phase 2).pdf
      Updated SRS v2.2 as one PDF: the Phase 1 content plus the new System Architecture and Design
      section, the design source links (section 6.2) and the Microsoft Project screenshot (Figure 16).
  TheZealotsSchedule.mpp
      Microsoft Project plan, the original editable file.
  TheZealotsSchedule (Phase 2 update 11 Oct).xml
      The same schedule with % complete and the Phase 2 development, testing, submission and
      defence tasks. Open in Microsoft Project with File > Open (file type: XML). Phase 3 tasks
      will be added when Phase 3 opens.
  Group Y - ITC327W Progress Checker.xlsx
      ITC327W Project Progress Tracker: task progress, individual contributions, stakeholder
      engagement, challenges and actions, phase summary and the Phase 2 group reflection.
  design-sources/
      spanner-all-designs.drawio      EVERY design in one file, one page each (13 pages). Open at
                                      https://app.diagrams.net and choose Device. Free, no account.
      *.drawio                        Each design as its own draw.io file.
      gary-flutter-mockups-obsidian/  Flutter mockups by Gary van Wyk (Obsidian Canvas). Open the
                                      folder as an Obsidian vault, or see page 12 of the draw.io file.
      kea-web-wireframe/              ASP.NET wireframe flow by Kea (Keamogetse Ogone Kgosi).
      denny-web-designs-figma/        ASP.NET designs by Denny (Mathye MD): HTML prototype,
                                      screenshots and the Figma link (page 13 of the draw.io file).

LINKS (all open without an account)
  GitHub repository:         https://github.com/BlackZ3ro/Spanner-Riese-Auto-Clinic
  All designs in draw.io:    https://app.diagrams.net/#Uhttps%3A%2F%2Fraw.githubusercontent.com%2FBlackZ3ro%2FSpanner-Riese-Auto-Clinic%2Frefs%2Fheads%2Fmain%2Fproject-docs%2Fphase-2%2Fdiagrams%2Feditable%2Fspanner-all-designs.drawio
  Use case diagram (Lucid):  https://lucid.app/lucidchart/fb4ebb76-2892-4f1a-888f-067c37aca98d/view
  Sequence diagrams (Lucid): https://lucid.app/lucidchart/285c1247-0f85-4e60-879c-90f48a0c91f6/view
  Web designs (Figma):       https://www.figma.com/proto/yoiClYQl9oJNOD2pCRRplW/riese-auto-clinic-final-design?node-id=22-2240&t=xsFRVUIDXuvZZXlL-1&scaling=min-zoom&content-scaling=fixed&page-id=0%3A1

Phase 2 presentation: Friday 16 October 2026, 12:00.
